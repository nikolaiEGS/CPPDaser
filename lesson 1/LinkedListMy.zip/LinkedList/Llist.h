#include <iostream>

template <typename T>
struct Node {
	using value_type = T;

	value_type value;
	Node* prev;
	Node* next;

	Node() : value(), prev(nullptr), next(nullptr) {}
	explicit Node(value_type newValue) : value(newValue), prev(nullptr), next(nullptr) {}
//	Node(const Node& x) : value(x.value), prev(x.prev), next(x.next) {}
};

template <typename T>
class Llist {
	using value_type = T;
	Node<value_type>* head;
	Node<value_type>* tail = new Node<T>();
	std::size_t size_ = 0;

	void releaseList(Llist<value_type>& right);
public:
	Llist()  { head = tail; }
	Llist(const Llist<value_type>& right);
	~Llist();

	void insert(const value_type& newElem);
	Llist<T>& operator+=(const Llist<value_type>& right);
	Llist<T>& operator=(const Llist<value_type>& right);

	void copyList(Llist<value_type>& destination, const Llist<value_type>& right);
	void printList() const noexcept(true);
	std::size_t size() const noexcept(true) { return size_; }

};
