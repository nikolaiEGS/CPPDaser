#include "Llist.h"

//#define DEBUG

#ifdef DEBUG
int delCount = 0;
int constrCount = 0;
#endif // DEBUG

template <typename T>
Llist<T>::Llist(const Llist<T>& right) {
	const Node<T>* currentRightNode = right.head;
	tail = new Node<T>();
	head = tail;

	if (right.size() == 0) {
		return;
	}

	copyList(*this, right);
}

template <typename T>
void Llist<T>::copyList(Llist<T>& destination, const Llist<T>& right) {
	const Node<T>* currentNode = right.head;

	while (currentNode != right.tail) {
		destination.insert(currentNode->value);
		currentNode = currentNode->next;
	}
}

template <typename T>
Llist<T>& Llist<T>::operator=(const Llist<T>& right) {
	if (this != &right) {
		releaseList(*this);
		tail = new Node<T>();
		head = tail;
		copyList(*this, right);
	}

	return *this;
}

template <typename T>
void Llist<T>::releaseList(Llist<T>& right) {
	Node<T>* currentNode = right.head;
	while (currentNode) {
		auto tempNode = currentNode->next;
#ifdef DEBUG
		std::cout << "DELETE: " << currentNode << " " << delCount--;
#endif
		delete currentNode;
		currentNode = tempNode;
	}
	size_ = 0;
	std::cout << std::endl;
}

template <typename T>
Llist<T>::~Llist() {
	releaseList(*this);
}

template <typename T>
void Llist<T>::insert(const T& newElem) {
	Node<T>* elem = new Node<T>(newElem);
#ifdef DEBUG
	std::cout << "CONSTRUCT: " << elem << " " << constrCount++;
#endif
	if (head == tail) {
		head = elem;
		head->next = tail;
		tail->prev = head;
	}
	else {
		head->prev = elem;
		elem->next = head;
		head = elem;
	}
	++size_;
}

template <typename T>
void Llist<T>::printList() const noexcept(true) {
	const Node<T>* currentNode = tail;

	while (currentNode != head) {
		currentNode = currentNode->prev;
		std::cout << currentNode->value << " ";
	}
	
	std::cout << std::endl;
}

template <typename T>
Llist<T>& Llist<T>::operator+=(const Llist<T>& right) {

	Node<T>* currentSelfNode = tail->prev;
	const Node<T>* currentRightNode = right.head;
	
	tail->prev = nullptr;

	while (currentRightNode != right.tail) {
		Node<T>* temp = new Node<T>(currentRightNode->value);
#ifdef DEBUG
		std::cout << "CONSTRUCT: " << temp << " " << constrCount++;
#endif
		currentSelfNode->next = temp;
		temp->prev = currentSelfNode;

		currentSelfNode = currentSelfNode->next;
		currentRightNode = currentRightNode->next;
		
		++size_;
	}

	currentSelfNode->next = tail;
	tail->prev = currentSelfNode;
	return *this;
}

int main() {
	Llist<float> l;

	l.insert(7.4);
	std::cout << "size: " << l.size() << std::endl;
	l.insert(7.8);
	l.insert(-5);
	l.insert(0);

	std::cout << "l:" << std::endl;
	l.printList();


	Llist<float> ll;
	ll.insert(100);
	ll .insert(200);
	std::cout << "ll:" << std::endl;
	ll.printList();

	l += ll;
	std::cout << "l:" << std::endl;
	l.printList();

	std::cout << "size l : " << l.size() << "size ll : " << ll.size() << std::endl;
	std::cout << std::endl << std::endl;

	/*
	Llist<float> c(Llist<float>{});
	std::cout << "c:" << std::endl;
	c.printList();
	std::cout << "size c: " << c.size() << std::endl;
	std::cout << std::endl << std::endl;
	*/
	Llist<float> cc(l += ll);
	std::cout << "cc:" << std::endl;
	cc.printList();
	std::cout << "size cc: " << cc.size() << std::endl;
	std::cout << std::endl << std::endl;


	cc = l+=ll;
	std::cout << "cc:" << std::endl;
	cc.printList();
	std::cout << "size cc: " << cc.size() << std::endl;


	cc = cc;
	std::cout << "cc:" << std::endl;
	cc.printList();
	std::cout << "size cc: " << cc.size() << std::endl;

	return 0;
}
